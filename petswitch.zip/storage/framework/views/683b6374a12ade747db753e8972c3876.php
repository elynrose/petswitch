<?php 
if(Auth::user()->timezone){
    date_default_timezone_set(Auth::user()->timezone);
}
date_default_timezone_set(Auth::user()->timezone);
?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-body">
                <h1 class="mb-5">Incoming Requests</h1>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_request_create')): ?>
                <div style="margin-bottom: 10px;" class="row">
                    <div class="col-lg-6 mb-3">
                        <a class="btn btn-success btn-sm" href="<?php echo e(route('frontend.service-requests.create')); ?>">
                            <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.serviceRequest.title_singular')); ?>

                        </a>
                    </div>
                    <div class="col-lg-6 mb-5">
                        <!-- Empty column -->
                    </div>
                </div>
                <?php endif; ?>
                <form action="<?php echo e(route('frontend.service-requests.index')); ?>" method="GET" class="">
                    <div class="row">
                        <div class="col-md-4 col-sm-12 mb-3">
                            <input type="text" name="zip" class="form-control" placeholder="Enter Zip Code" required>
                        </div>
                        <div class="col-md-4 col-sm-12 mb-3">
                            <select name="radius" class="form-control mb-2" required>
                                <option value="5" <?php echo e(request()->input('radius') == 5 ? 'selected' : ''); ?>>5 miles</option>
                                <option value="10" <?php echo e(request()->input('radius') == 10 ? 'selected' : ''); ?>>10 miles</option>
                                <option value="25" <?php echo e(request()->input('radius') == 25 ? 'selected' : ''); ?>>25 miles</option>
                                <option value="50" <?php echo e(request()->input('radius') == 50 ? 'selected' : ''); ?>>50 miles</option>
                                <option value="100" <?php echo e(request()->input('radius') == 100 ? 'selected' : ''); ?>>100 miles</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-2">
                            <button type="submit" class="btn btn-md btn-primary" style="max-height:">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card">
            <?php
            $today = \Carbon\Carbon::now()->timezone(Auth::user()->timezone);
            ?>
            <?php if($serviceRequests->count()): ?>
            




            <?php $__currentLoopData = $serviceRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $serviceRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card shadow mb-5">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 col-sm-12">
                            <div style="position:relative;">
                                <?php if($serviceRequest->user->profile_photo): ?>
                                <img src="<?php echo e($serviceRequest->user->profile_photo->getUrl('thumb')); ?>" class="user-image shadow" data-id="<?php echo e($serviceRequest->user->id); ?>" id="user-img-<?php echo e($serviceRequest->user->id); ?>" style="position: absolute; bottom: 10px; right: 10px; width: 80px; height: 80px; border-radius: 50%;">
                                <?php else: ?>
                                <img src="<?php echo e(asset('/assets/images/User.png')); ?>" class="user-image shadow" data-id="<?php echo e($serviceRequest->user->id); ?>" class="user-image shadow" data-id="<?php echo e($serviceRequest->user->id); ?>" id="pet-img-<?php echo e($serviceRequest->user->id); ?>" style="position: absolute; bottom: 10px; right: 10px; width: 80px; height: 80px; border-radius: 50%;">
                                <?php endif; ?>
                                <img src="<?php echo e($serviceRequest->pet->photos->getUrl('preview')); ?>" class="pet-image" data-id="<?php echo e($serviceRequest->pet->id); ?>" id="pet-img-<?php echo e($serviceRequest->pet->id); ?>">
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="mt-1"><?php echo e($serviceRequest->user->name ?? ''); ?> <?php echo e(_('needs')); ?> <?php echo e($serviceRequest->service->name ?? ''); ?> <?php echo e(_('for')); ?> <?php echo e($serviceRequest->pet->name ?? ''); ?></h4>
                                    <p class="small text-muted"> Posted <?php echo e($serviceRequest->created_at->diffForHumans()); ?></p>
                                    <?php if($serviceRequest->booking): ?>
                                    <?php
                                    $today = \Carbon\Carbon::now()->timezone(Auth::user()->timezone);
                                    $fromDateTime = \Carbon\Carbon::parse($serviceRequest->from)->timezone(Auth::user()->timezone);
                                    $toDateTime = \Carbon\Carbon::parse($serviceRequest->to)->timezone(Auth::user()->timezone);
                                    ?>
                                    <?php endif; ?>
                                    <div class="media-container-row">
                                        <div class="media-content">
                                            <?php if($serviceRequest->decline == 0 && $serviceRequest->pending == 0 && $fromDateTime > $today): ?>
                                            <p><p class="badge badge-success"><?php echo e(_('New')); ?></p>
                                            <?php elseif($fromDateTime < $today && $toDateTime > $today && $serviceRequest->decline == 0 && $serviceRequest->closed == 0 && $serviceRequest->pending == 1): ?>
                                            <p class="badge badge-success"><?php echo e(_('Booked')); ?></p>
                                            <?php elseif($toDateTime < $today && $serviceRequest->decline == 0 && $serviceRequest->closed == 0 && $serviceRequest->pending == 0): ?>
                                            <p class="badge badge-danger"><?php echo e(_('Expired')); ?></p>
                                            <?php elseif($fromDateTime <= $today && $toDateTime >= $today && $serviceRequest->decline == 0 && $serviceRequest->closed == 0 && $serviceRequest->pending == 1 ): ?>
                                            <p class="badge badge-info"><?php echo e(_('Ongoing')); ?></p>
                                            <?php elseif($fromDateTime > $today && $serviceRequest->decline == 0 && $serviceRequest->closed == 0 && $serviceRequest->pending == 1): ?>
                                            <p class="badge badge-info"><?php echo e(_('Upcoming')); ?></p>
                                            <?php elseif($serviceRequest->pending==2 && $serviceRequest->decline == 0  && $serviceRequest->to < $today): ?>
                                            <p class="badge badge-warning"><?php echo e(_('Completed')); ?></p>
                                            <?php endif; ?>
                                            <div class="row">
                                                <div class="col-md-5">
                                                    <p><strong><?php echo e(_('Size')); ?></strong>: <?php echo e($serviceRequest->pet::SIZE_SELECT[$serviceRequest->pet->size] ?? ''); ?> <?php echo e(_('lbs')); ?></p>
                                                    <p><strong><?php echo e(_('Age')); ?></strong>: <?php echo e($serviceRequest->pet->age ?? ''); ?> <?php echo e(_('y/o')); ?></p>
                                                    <p><strong><?php echo e(_('Gets Along With')); ?></strong>: <?php echo e($serviceRequest->pet::GETS_ALONG_WITH_RADIO[$serviceRequest->pet->gets_along_with] ?? ''); ?></p>
                                                    <p><strong><?php echo e(_('Is Immunized')); ?></strong>: <input type="checkbox" disabled="disabled" <?php echo e($serviceRequest->pet->is_immunized ? 'checked' : ''); ?>></p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p><strong><?php echo e(_('Zip Code')); ?></strong>: <?php echo e($serviceRequest->zip_code ?? ''); ?></p>
                                                    <p><strong><?php echo e(_('Pickup')); ?></strong>: <?php echo e(\Carbon\Carbon::parse($serviceRequest->from)->format('l, F j, Y, g:i A') ?? ''); ?></p>
                                                    <p><strong><?php echo e(_('Drop-off')); ?></strong>: <?php echo e(\Carbon\Carbon::parse($serviceRequest->to)->format('l, F j, Y, g:i A') ?? ''); ?></p>
                                                    <p>
                                                        <?php if($serviceRequest->closed==1): ?>
                                                        <a class="btn btn-success btn-sm" href="<?php echo e(route('frontend.service-requests.completed', $serviceRequest->id)); ?>"><?php echo e(trans('global.completed')); ?></a>
                                                        <?php elseif($serviceRequest->closed==0): ?>
                                                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('frontend.service-requests.show', $serviceRequest->id)); ?>"><?php echo e(trans('global.view')); ?></a>
                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                                <div class="col-md-1">
                                                    <?php if(Auth::id()): ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_request_delete')): ?>
                                                    <form action="<?php echo e(route('admin.service-requests.destroy', $serviceRequest->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                                        <?php echo method_field('POST'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                        <button type="submit" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></button>
                                                    </form>
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>








            <?php else: ?>
            <div class="card-body">
                <h4><?php echo e(_('No Help Needed Right Now. Relax and Chill')); ?></h4>
            </div>
            <?php endif; ?>

            <?php if(!Request::has('zip') && !Request::has('radius')): ?>
            <div class="card-footer">
                <?php echo e($serviceRequests->links()); ?>

            </div>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_request_delete')): ?>
        let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
        let deleteButton = {
            text: deleteButtonTrans,
            url: "<?php echo e(route('frontend.service-requests.massDestroy')); ?>",
            className: 'btn-danger',
            action: function (e, dt, node, config) {
                var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
                    return $(entry).data('entry-id')
                });

                if (ids.length === 0) {
                    alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')
                    return
                }

                if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
                    $.ajax({
                        headers: {'x-csrf-token': _token},
                        method: 'POST',
                        url: config.url,
                        data: { ids: ids, _method: 'DELETE' }
                    })
                    .done(function () { location.reload() })
                }
            }
        }
        dtButtons.push(deleteButton)
        <?php endif; ?>

        $.extend(true, $.fn.dataTable.defaults, {
            orderCellsTop: true,
            order: [[ 1, 'desc' ]],
            pageLength: 100,
        });
        let table = $('.datatable-ServiceRequest:not(.ajaxTable)').DataTable({ buttons: dtButtons })
        $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
        });
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_pawflips\resources\views/frontend/home.blade.php ENDPATH**/ ?>