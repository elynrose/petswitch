<?php $__env->startSection('content'); ?>
<section class="features15 agencym4_features15 cid-ucRMkyKyoy" id="features15-3a">
  <div class="container">
    <h1 class="mb-5"><?php echo e(trans('cruds.pet.my_pets')); ?></h1>
    <div class="row">
      <div class="col-lg-12">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pet_create')): ?>
        <a class="btn btn-success btn-sm" href="<?php echo e(route('frontend.pets.create')); ?>">
          <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.pet.title_singular')); ?>

        </a>
        <?php endif; ?>
      </div>
    </div>
    <div class="row">
      <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-12 col-md-4 col-lg-3">
        <div class="card shadow">
          <div class="card-img">
            <?php if($pet->photos): ?>
            <img src="<?php echo e($pet->photos->getUrl('preview')); ?>">
            <?php endif; ?>
          </div>
          <div class="card-box">
            <h4 class="card-title mbr-fonts-style display-5"><?php echo e($pet->name ?? ''); ?></h4>
            <p class="small">
            <!--Count completed service requests-->
            <?php echo e(\App\Models\ServiceRequest::where('closed', 1)->where('pet_id', $pet->id)->count()); ?> <?php echo e(_('completed request(s)')); ?>

            </p>
          </div>
          <div class="justify-content-center">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pet_edit')): ?>
            <a class="btn btn-xs btn-info" href="<?php echo e(route('frontend.pets.edit', $pet->id)); ?>">
            <i class="fas fa-edit"></i>
            </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pet_delete')): ?>
            <form action="<?php echo e(route('frontend.pets.destroy', $pet->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>"><i class="fas fa-trash"></i></button>
            </form>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
  $(function () {
    let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons);
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pet_delete')): ?>
    let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>';
    let deleteButton = {
      text: deleteButtonTrans,
      url: "<?php echo e(route('frontend.pets.massDestroy')); ?>",
      className: 'btn-danger',
      action: function (e, dt, node, config) {
        var ids = dt.rows({ selected: true }).nodes().toArray().map(function (entry) {
          return $(entry).data('entry-id');
        });

        if (ids.length === 0) {
          alert('<?php echo e(trans('global.datatables.zero_selected')); ?>');
          return;
        }

        if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
          $.ajax({
            headers: { 'x-csrf-token': _token },
            method: 'POST',
            url: config.url,
            data: { ids: ids, _method: 'DELETE' }
          })
          .done(function () { location.reload(); });
        }
      }
    };
    dtButtons.push(deleteButton);
    <?php endif; ?>

    $.extend(true, $.fn.dataTable.defaults, {
      orderCellsTop: true,
      order: [[1, 'desc']],
      pageLength: 100,
    });

    let table = $('.datatable-Pet:not(.ajaxTable)').DataTable({ buttons: dtButtons });

    $('a[data-toggle="tab"]').on('shown.bs.tab click', function (e) {
      $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/frontend/pets/index.blade.php ENDPATH**/ ?>