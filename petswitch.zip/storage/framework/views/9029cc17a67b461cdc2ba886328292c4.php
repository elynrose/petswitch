<?php $__env->startSection('content'); ?>

<section class="features15 agencym4_features15 cid-ucRMkyKyoy" id="features15-3a">
    
	<div class="container">
    <h1 class="mb-5">Members in your area</h1>
    <form action="<?php echo e(route('frontend.users.index')); ?>" method="get">
        <div class="form-row">
            <div class="form-group
            col-md-3">
                <input type="text" class="form-control" id="zip" name="zip" value="<?php echo e(request()->input('zip')); ?>">
            </div>
            <div class="form-group col-md-6">
                <select id="radius" class="form-control" name="radius">
                    <option value="5" <?php echo e(request()->input('radius') == 5 ? 'selected' : ''); ?>>5 miles</option>
                    <option value="10" <?php echo e(request()->input('radius') == 10 ? 'selected' : ''); ?>>10 miles</option>
                    <option value="25" <?php echo e(request()->input('radius') == 25 ? 'selected' : ''); ?>>25 miles</option>
                    <option value="50" <?php echo e(request()->input('radius') == 50 ? 'selected' : ''); ?>>50 miles</option>
                    <option value="100" <?php echo e(request()->input('radius') == 100 ? 'selected' : ''); ?>>100 miles</option>
                </select>
            </div>
            <div class="form-group col-md-3">
            <button type="submit" class="btn btn-primary">Search</button>

</div>
        </div>
    </form>

		<div class="media-container-row">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card col-12 col-md-3 col-lg-3">
				<div class="card-img">
          <a href="<?php echo e(route('frontend.users.show', $user->id )); ?>">
                    <?php if($user->profile_photo): ?>
                                                <img src="<?php echo e($user->profile_photo->getUrl('preview')); ?>">
                                        <?php else: ?> 
                                        <img src="<?php echo e(asset('/assets/images/User.png')); ?>">
                                      <?php endif; ?></a>
				</div>
				<div class="card-box">
					<h4 class="card-title mbr-fonts-style display-5"><?php echo e($user->name ?? 'User'); ?></h4>
					<p class="mbr-text mbr-fonts-style display-4"><strong><?php echo e($user->city ?? ''); ?><?php if($user->state): ?> <?php echo e(_(',')); ?> <?php endif; ?><?php echo e($user->state ?? ''); ?>   </strong></p>
          <p class="display-9 small">Total Credits: <?php echo e(App\models\Credit::where('user_id', $user->id)->sum('points') ?? 'New'); ?> <br> 
          Member Since: <?php echo e($user->created_at->diffForHumans()); ?>

          
        </p>


					<div class="mbr-section-btn"><a class="btn-underline display-4" href="<?php echo e(route('frontend.users.show', $user->id )); ?>">Profile</a></div>
				</div>
			</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
		
			
		</div>

        <div class="pagination">
            <?php if(!Request::get('zip') && !Request::get('radius')): ?>
                <?php echo e($users->links()); ?>

            <?php endif; ?>
            </div>

	</div>
</section>





<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('frontend.users.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-User:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/frontend/users/index.blade.php ENDPATH**/ ?>