<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
          
                <div class="card-body">
              <h1 class="mb-5">  <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.serviceRequest.title_singular')); ?> </h1>

                    <form method="POST" action="<?php echo e(route("frontend.service-requests.update", [$serviceRequest->id])); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="required" for="service_id"><?php echo e(trans('cruds.serviceRequest.fields.service')); ?></label>
                            <select class="form-control select" name="service_id" id="service_id" required>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e((old('service_id') ? old('service_id') : $serviceRequest->service->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e(ucfirst($entry)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('service')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('service')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.serviceRequest.fields.service_helper')); ?></span>
                        </div>
                    
                        <div class="form-group">
                            <label class="required" for="from"><?php echo e(trans('cruds.serviceRequest.fields.from')); ?></label>
                            <input class="form-control datetime" type="text" name="from" id="from" value="<?php echo e(old('from', $serviceRequest->from)); ?>" required>
                            <?php if($errors->has('from')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('from')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.serviceRequest.fields.from_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="to"><?php echo e(trans('cruds.serviceRequest.fields.to')); ?></label>
                            <input class="form-control datetime" type="text" name="to" id="to" value="<?php echo e(old('to', $serviceRequest->to)); ?>" required>
                            <?php if($errors->has('to')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('to')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.serviceRequest.fields.to_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="comments"><?php echo e(trans('cruds.serviceRequest.fields.comments')); ?></label>
                            <textarea class="form-control ckeditor" name="comments" id="comments"><?php echo old('comments', $serviceRequest->comments); ?></textarea>
                            <?php if($errors->has('comments')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('comments')); ?>

                                </div>
                            <?php endif; ?>
<br>
                            <span class="help-block small"><?php echo e(trans('cruds.serviceRequest.fields.comments_helper')); ?></span>
                        </div>
                       
                        <div class="form-group">
                            <input type="hidden" name="pet_id" value="<?php echo e($serviceRequest->pet->id); ?>">
                            <input type="hidden" name="zip_code" value="$serviceRequest->zip_code">
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <button class="btn btn-primary btn-sm" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('frontend.service-requests.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($serviceRequest->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_pawflips\resources\views/frontend/serviceRequests/edit.blade.php ENDPATH**/ ?>