<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
       

                <div class="card-body">
                    <h1 class="py-5">Add a pet</h1>
                    <form method="POST" action="<?php echo e(route("frontend.pets.store")); ?>" enctype="multipart/form-data">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="photos"><?php echo e(trans('cruds.pet.fields.photos')); ?></label>
                            <div class="needsclick dropzone" id="photos-dropzone">
                            </div>
                            <?php if($errors->has('photos')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('photos')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pet.fields.photos_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="animal_id"><?php echo e(trans('cruds.pet.fields.animal')); ?></label>
                            <select class="form-control select" name="animal_id" id="animal_id" required>
                                <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e(old('animal_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('animal')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('animal')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pet.fields.animal_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="name"><?php echo e(trans('cruds.pet.fields.name')); ?></label>
                            <input class="form-control" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                            <?php if($errors->has('name')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('name')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pet.fields.name_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="breed"><?php echo e(trans('cruds.pet.fields.breed')); ?></label>
                            <input class="form-control" type="text" name="breed" id="breed" value="<?php echo e(old('breed', '')); ?>" required>
                            <?php if($errors->has('breed')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('breed')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pet.fields.breed_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required"><?php echo e(trans('cruds.pet.fields.size')); ?></label>
                            <select class="form-control" name="size" id="size" required>
                                <option value disabled <?php echo e(old('size', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                                <?php $__currentLoopData = App\Models\Pet::SIZE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>" <?php echo e(old('size', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('size')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('size')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pet.fields.size_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="age"><?php echo e(trans('cruds.pet.fields.age')); ?></label>
                            <input class="form-control" type="text" name="age" id="age" value="<?php echo e(old('age', '')); ?>" required>
                            <?php if($errors->has('age')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('age')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pet.fields.age_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required"><?php echo e(trans('cruds.pet.fields.gender')); ?></label>
                            <select class="form-control" name="gender" id="gender" required>
                                <option value disabled <?php echo e(old('gender', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                                <?php $__currentLoopData = App\Models\Pet::GENDER_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>" <?php echo e(old('gender', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('gender')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('gender')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pet.fields.gender_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required"><?php echo e(trans('cruds.pet.fields.gets_along_with')); ?></label>
                            <?php $__currentLoopData = App\Models\Pet::GETS_ALONG_WITH_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <input type="radio" id="gets_along_with_<?php echo e($key); ?>" name="gets_along_with" value="<?php echo e($key); ?>" <?php echo e(old('gets_along_with', '') === (string) $key ? 'checked' : ''); ?> required>
                                    <label for="gets_along_with_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($errors->has('gets_along_with')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('gets_along_with')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pet.fields.gets_along_with_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <div>
                                <input type="hidden" name="is_immunized" value="0">
                                <input type="checkbox" name="is_immunized" id="is_immunized" value="1" <?php echo e(old('is_immunized', 0) == 1 ? 'checked' : ''); ?>>
                                <label for="is_immunized"><?php echo e(trans('cruds.pet.fields.is_immunized')); ?></label>
                            </div>
                            <?php if($errors->has('is_immunized')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('is_immunized')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pet.fields.is_immunized_helper')); ?></span>
                        </div>
                        <div class="form-group">
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
                        <input type="hidden" name="fire" value="">
                            <button class="btn btn-success" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.photosDropzone = {
    url: '<?php echo e(route('frontend.pets.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="photos"]').remove()
      $('form').append('<input type="hidden" name="photos" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="photos"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($pet) && $pet->photos): ?>
      var file = <?php echo json_encode($pet->photos); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview ?? file.preview_url)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="photos" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_pawflips\resources\views/frontend/pets/create.blade.php ENDPATH**/ ?>