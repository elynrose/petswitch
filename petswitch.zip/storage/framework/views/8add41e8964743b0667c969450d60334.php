<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.user.title_singular')); ?>

                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route("frontend.users.update", [$user->id])); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="profile_photo"><?php echo e(trans('cruds.user.fields.profile_photo')); ?></label>
                            <div class="needsclick dropzone" id="profile_photo-dropzone">
                            </div>
                            <?php if($errors->has('profile_photo')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('profile_photo')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.profile_photo_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="name"><?php echo e(trans('cruds.user.fields.name')); ?></label>
                            <input class="form-control" type="text" name="name" id="name" value="<?php echo e(old('name', $user->name)); ?>" required>
                            <?php if($errors->has('name')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('name')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.name_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="last_name"><?php echo e(trans('cruds.user.fields.last_name')); ?></label>
                            <input class="form-control" type="text" name="last_name" id="last_name" value="<?php echo e(old('last_name', $user->last_name)); ?>" required>
                            <?php if($errors->has('last_name')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('last_name')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.last_name_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="bio"><?php echo e(trans('cruds.user.fields.bio')); ?></label>
                            <textarea class="form-control" name="bio" id="bio"><?php echo e(old('bio', $user->bio)); ?></textarea>
                            <?php if($errors->has('bio')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('bio')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.bio_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="email"><?php echo e(trans('cruds.user.fields.email')); ?></label>
                            <input class="form-control" type="email" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>" required>
                            <?php if($errors->has('email')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('email')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.email_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="password"><?php echo e(trans('cruds.user.fields.password')); ?></label>
                            <input class="form-control" type="password" name="password" id="password">
                            <?php if($errors->has('password')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('password')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.password_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(trans('cruds.user.fields.country')); ?></label>
                            <select class="form-control" name="country" id="country">
                                <option value disabled <?php echo e(old('country', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                                <?php $__currentLoopData = App\Models\User::COUNTRY_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>" <?php echo e(old('country', $user->country) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('country')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('country')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.country_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(trans('cruds.user.fields.state')); ?></label>
                            <select class="form-control" name="state" id="state">
                                <option value disabled <?php echo e(old('state', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                                <?php $__currentLoopData = App\Models\User::STATE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>" <?php echo e(old('state', $user->state) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('state')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('state')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.state_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="city"><?php echo e(trans('cruds.user.fields.city')); ?></label>
                            <input class="form-control" type="text" name="city" id="city" value="<?php echo e(old('city', $user->city)); ?>">
                            <?php if($errors->has('city')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('city')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.city_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="zip"><?php echo e(trans('cruds.user.fields.zip')); ?></label>
                            <input class="form-control" type="text" name="zip" id="zip" value="<?php echo e(old('zip', $user->zip)); ?>">
                            <?php if($errors->has('zip')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('zip')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.zip_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <div>
                                <input type="hidden" name="conscent" value="0">
                                <input type="checkbox" name="conscent" id="conscent" value="1" <?php echo e($user->conscent || old('conscent', 0) === 1 ? 'checked' : ''); ?>>
                                <label for="conscent"><?php echo e(trans('cruds.user.fields.conscent')); ?></label>
                            </div>
                            <?php if($errors->has('conscent')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('conscent')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.conscent_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <div>
                                <input type="hidden" name="email_notification" value="0">
                                <input type="checkbox" name="email_notification" id="email_notification" value="1" <?php echo e($user->email_notification || old('email_notification', 0) === 1 ? 'checked' : ''); ?>>
                                <label for="email_notification"><?php echo e(trans('cruds.user.fields.email_notification')); ?></label>
                            </div>
                            <?php if($errors->has('email_notification')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('email_notification')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.email_notification_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <div>
                                <input type="hidden" name="sms_notification" value="0">
                                <input type="checkbox" name="sms_notification" id="sms_notification" value="1" <?php echo e($user->sms_notification || old('sms_notification', 0) === 1 ? 'checked' : ''); ?>>
                                <label for="sms_notification"><?php echo e(trans('cruds.user.fields.sms_notification')); ?></label>
                            </div>
                            <?php if($errors->has('sms_notification')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('sms_notification')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.sms_notification_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="banned"><?php echo e(trans('cruds.user.fields.banned')); ?></label>
                            <input class="form-control" type="number" name="banned" id="banned" value="<?php echo e(old('banned', $user->banned)); ?>" step="1">
                            <?php if($errors->has('banned')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('banned')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.banned_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="roles"><?php echo e(trans('cruds.user.fields.roles')); ?></label>
                            <div style="padding-bottom: 4px">
                                <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                                <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                            </div>
                            <select class="form-control select2" name="roles[]" id="roles" multiple required>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('roles', [])) || $user->roles->contains($id)) ? 'selected' : ''); ?>><?php echo e($role); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('roles')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('roles')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.roles_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="expiry"><?php echo e(trans('cruds.user.fields.expiry')); ?></label>
                            <input class="form-control date" type="text" name="expiry" id="expiry" value="<?php echo e(old('expiry', $user->expiry)); ?>">
                            <?php if($errors->has('expiry')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('expiry')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.user.fields.expiry_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.profilePhotoDropzone = {
    url: '<?php echo e(route('frontend.users.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="profile_photo"]').remove()
      $('form').append('<input type="hidden" name="profile_photo" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="profile_photo"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($user) && $user->profile_photo): ?>
      var file = <?php echo json_encode($user->profile_photo); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview ?? file.preview_url)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="profile_photo" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_pawflips\resources\views/frontend/users/edit.blade.php ENDPATH**/ ?>