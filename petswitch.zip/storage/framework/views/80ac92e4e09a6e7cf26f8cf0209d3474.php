<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.petReview.title_singular')); ?>

                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route("frontend.pet-reviews.store")); ?>" enctype="multipart/form-data">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="pet_id"><?php echo e(trans('cruds.petReview.fields.pet')); ?></label>
                            <select class="form-control select2" name="pet_id" id="pet_id">
                                <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e(old('pet_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('pet')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('pet')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.petReview.fields.pet_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="booking_id"><?php echo e(trans('cruds.petReview.fields.booking')); ?></label>
                            <select class="form-control select2" name="booking_id" id="booking_id" required>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e(old('booking_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('booking')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('booking')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.petReview.fields.booking_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="comment"><?php echo e(trans('cruds.petReview.fields.comment')); ?></label>
                            <textarea class="form-control" name="comment" id="comment" required><?php echo e(old('comment')); ?></textarea>
                            <?php if($errors->has('comment')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('comment')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.petReview.fields.comment_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="rating"><?php echo e(trans('cruds.petReview.fields.rating')); ?></label>
                            <input class="form-control" type="number" name="rating" id="rating" value="<?php echo e(old('rating', '')); ?>" step="1" required>
                            <?php if($errors->has('rating')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('rating')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.petReview.fields.rating_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_pawflips\resources\views/frontend/petReviews/create.blade.php ENDPATH**/ ?>