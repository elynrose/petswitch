<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.booking.title')); ?>

                </div>

                <div class="card-body">
                    <div class="form-group">
                        <div class="form-group">
                            <a class="btn btn-default" href="<?php echo e(route('frontend.bookings.index')); ?>">
                                <?php echo e(trans('global.back_to_list')); ?>

                            </a>
                        </div>
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.booking.fields.id')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($booking->id); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.booking.fields.service_request')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($booking->service_request->from ?? ''); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.booking.fields.decline')); ?>

                                    </th>
                                    <td>
                                        <input type="checkbox" disabled="disabled" <?php echo e($booking->decline ? 'checked' : ''); ?>>
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.booking.fields.user')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($booking->user->name ?? ''); ?>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="form-group">
                            <a class="btn btn-default" href="<?php echo e(route('frontend.bookings.index')); ?>">
                                <?php echo e(trans('global.back_to_list')); ?>

                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_pawflips\resources\views/frontend/bookings/show.blade.php ENDPATH**/ ?>