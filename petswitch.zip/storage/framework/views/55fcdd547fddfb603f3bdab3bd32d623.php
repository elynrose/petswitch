<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">


                <div class="card-body">
                <h1 class="mb-5">
                    <?php echo e(trans('cruds.credit.title_singular')); ?> 
</h1>
                  <p class="mb-5 alert alert-info"><i class="fa fa-star"></i> You have  <?php echo e($credits->points ?? ''); ?> Credits</p>

                  <h4>How to earn credits</h4>
                  <p>You can earn credits by the number of hours you care for other peoples pets.</p>
                
                <h4 class="mt-5">Invitation Code</h4>
                <p>Share your invitation code with friends and earn credits when they sign up.</p>
                <p>Your invitation code is: <strong><?php echo e(Auth::user()->invitation_code ?? ''); ?></strong></p>
                
                <h4 class="mt-5">Referral Link</h4>
                <p>Share your referral link with friends and earn 3 credits when they sign up. That's three hours of free pet care.</p>
                <p>Your referral link is: <strong><?php echo e(route('register')); ?>?referral=<?php echo e(Auth::user()->invitation_code ?? ''); ?></strong></p>
                <h4 class="mt-5 mb-5"> Sample letter to send to your friends</h4>
                <div class="bg-light p-4">
                        <p>Dear [Friend's Name],</p>
    <p>I hope this message finds you and your furry friend well!</p>
    <p>I wanted to share something amazing with you – I've joined <strong><?php echo e(trans('panel.site_title')); ?></strong>, a wonderful community of pet lovers dedicated to providing safe and loving care for our pets. It's been such a relief knowing that my pet is in good hands whenever I need help.</p>
    <p>Here's why I think you'll love it too:</p>
    <ul>
        <li><strong>Earn and Use Credits:</strong> Care for other pets and earn credits, which you can use when you need care for your own pet.</li>
        <li><strong>Verified Members:</strong> All members go through a verification process to ensure trust and safety.</li>
        <li><strong>Multiple Care Options:</strong> Choose from day care, boarding, or play dates for your pet.</li>
    </ul>
    <p>I think you and your furry friend will really benefit from this supportive community. Plus, it's a great way to meet other pet owners and share our love for our furry family members.</p>
    <p>You can sign up using this link: <a href="<?php echo e(route('register')); ?>?referral=<?php echo e(Auth::user()->invitation_code ?? ''); ?>"><?php echo e(route('register')); ?>?referral=<?php echo e(Auth::user()->invitation_code ?? ''); ?></a></p>
    <p>Looking forward to seeing you and furry friend on <?php echo e(trans('panel.site_title')); ?>!</p>
    <p>Warm regards,</p>
    <p><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->last_name); ?><br>
    </p>
</div>
            </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('credit_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('frontend.credits.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-Credit:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/frontend/credits/index.blade.php ENDPATH**/ ?>