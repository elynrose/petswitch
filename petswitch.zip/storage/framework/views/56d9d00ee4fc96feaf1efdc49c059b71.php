<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.review.title_singular')); ?>

                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route("frontend.reviews.store")); ?>" enctype="multipart/form-data">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="required" for="service_request_id"><?php echo e(trans('cruds.review.fields.service_request')); ?></label>
                            <select class="form-control select2" name="service_request_id" id="service_request_id" required>
                                <?php $__currentLoopData = $service_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e(old('service_request_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('service_request')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('service_request')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.review.fields.service_request_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="rating"><?php echo e(trans('cruds.review.fields.rating')); ?></label>
                            <input class="form-control" type="number" name="rating" id="rating" value="<?php echo e(old('rating', '')); ?>" step="1" required>
                            <?php if($errors->has('rating')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('rating')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.review.fields.rating_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="comment"><?php echo e(trans('cruds.review.fields.comment')); ?></label>
                            <textarea class="form-control" name="comment" id="comment" required><?php echo e(old('comment')); ?></textarea>
                            <?php if($errors->has('comment')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('comment')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.review.fields.comment_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="user_id"><?php echo e(trans('cruds.review.fields.user')); ?></label>
                            <select class="form-control select2" name="user_id" id="user_id" required>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e(old('user_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('user')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('user')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.review.fields.user_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_pawflips\resources\views/frontend/reviews/create.blade.php ENDPATH**/ ?>