<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
            <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>


                <div class="card-body">
                    <h1 class="mb-5"><?php echo e(trans('cruds.serviceRequest.new')); ?></h1>
                    <form method="POST" action="<?php echo e(route("frontend.service-requests.store")); ?>" enctype="multipart/form-data">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="required" for="service_id"><?php echo e(trans('cruds.serviceRequest.fields.service')); ?></label>
                            <select class="form-control select" name="service_id" id="service_id" required>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e(old('service_id') == $id ? 'selected' : ''); ?>><?php echo e(ucfirst($entry)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('service')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('service')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.serviceRequest.fields.service_helper')); ?></span>
                        </div>
                 
                        <div class="form-group card-body">
    <label class="required" for="pet_id"><?php echo e(trans('cruds.serviceRequest.fields.pet')); ?></label><br>
    <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="pet-selection" style="display:inline-block; margin: 15px;">
           <p><img src="<?php echo e($pet->photos->getUrl('thumb')); ?>" class="pet-image" data-id="<?php echo e($pet->id); ?>" id="pet-img-<?php echo e($pet->id); ?>"></p>
           <p> <?php echo e($pet->name ?? ''); ?> </p>
           <p> <input type="radio" name="pet_id" value="<?php echo e($pet->id); ?>" class="pet-radio" data-id="<?php echo e($pet->id); ?>"></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($errors->has('pet')): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first('pet')); ?>

        </div>
    <?php endif; ?>
    <span class="help-block"><?php echo e(trans('cruds.serviceRequest.fields.pet_helper')); ?></span>
</div>

                        <div class="form-group">
                            <label class="required" for="zip_code"><?php echo e(trans('cruds.serviceRequest.fields.zip_code')); ?></label>
                            <input class="form-control" type="number" name="zip_code" id="zip_code" value="<?php echo e(old('zip_code', '')); ?>" step="1" required>
                            <?php if($errors->has('zip_code')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('zip_code')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.serviceRequest.fields.zip_code_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="from"><?php echo e(trans('cruds.serviceRequest.fields.from')); ?></label>
                            <input class="form-control datetime" type="text" name="from" id="from" value="<?php echo e(old('from')); ?>" required>
                            <?php if($errors->has('from')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('from')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.serviceRequest.fields.from_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="to"><?php echo e(trans('cruds.serviceRequest.fields.to')); ?></label>
                            <input class="form-control datetime" type="text" name="to" id="to" value="<?php echo e(old('to')); ?>" required>
                            <?php if($errors->has('to')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('to')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.serviceRequest.fields.to_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="comments"><?php echo e(trans('cruds.serviceRequest.fields.comments')); ?></label>
                            <textarea class="form-control ckeditor" name="comments" id="comments"><?php echo old('comments'); ?></textarea>
                            <?php if($errors->has('comments')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('comments')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block small"><?php echo e(trans('cruds.serviceRequest.fields.comments_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-success" type="submit">
                                <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
                                <?php echo e(trans('cruds.serviceRequest.fields.submit_request')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const radios = document.querySelectorAll('.pet-radio');
        radios.forEach(radio => {
            radio.addEventListener('change', function () {
                radios.forEach(r => {
                    const id = r.getAttribute('data-id');
                    const img = document.getElementById(`pet-img-${id}`);
                    if (r.checked) {
                        img.classList.add('selected-pet');
                    } else {
                        img.classList.remove('selected-pet');
                    }
                });
            });
            // Ensure that images are highlighted if radios are pre-checked
            if (radio.checked) {
                const id = radio.getAttribute('data-id');
                const img = document.getElementById(`pet-img-${id}`);
                img.classList.add('selected-pet');
            }
        });
    });
</script>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('frontend.service-requests.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($serviceRequest->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/frontend/serviceRequests/create.blade.php ENDPATH**/ ?>