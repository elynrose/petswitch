<?php 
if(Auth::user()->timezone){
    date_default_timezone_set(Auth::user()->timezone);
}
date_default_timezone_set(Auth::user()->timezone);
?>

<?php $__env->startSection('content'); ?>
<section class="py-5" style="background:black!important;">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<?php if($serviceRequest->booking): ?>
				<?php
				$today = \Carbon\Carbon::now()->timezone(Auth::user()->timezone);
				$fromDateTime = \Carbon\Carbon::parse($serviceRequest->from)->timezone(Auth::user()->timezone);
				$toDateTime = \Carbon\Carbon::parse($serviceRequest->to)->timezone(Auth::user()->timezone);
				// Get the pet rating
				$rating = App\Models\PetReview::where('pet_id', $serviceRequest->pet->id)->avg('rating');
				$rating_count = App\Models\PetReview::where('pet_id', $serviceRequest->pet->id)->count();
				?>
				<?php endif; ?>
				<div class="media-container-row">
					<div class="media-content">
					<?php if($serviceRequest->decline == 0 && $serviceRequest->pending == 0 && $fromDateTime > $today): ?>
						<p class="badge badge-success"><?php echo e(_('New')); ?></p>
						<?php elseif($fromDateTime < $today && $toDateTime > $today && $serviceRequest->decline == 0 && $serviceRequest->closed == 0 && $serviceRequest->pending == 1): ?>
						<p class="badge badge-success"><?php echo e(_('Booked')); ?></p>
						<?php elseif($toDateTime < $today && $serviceRequest->decline == 0 && $serviceRequest->closed == 0 && $serviceRequest->pending == 0): ?>
						<p class="badge badge-danger"><?php echo e(_('Expired')); ?></p>
						<?php elseif($fromDateTime <= $today && $toDateTime >= $today && $serviceRequest->decline == 0 && $serviceRequest->closed == 0 && $serviceRequest->pending == 1 ): ?>
						<p class="badge badge-info"><?php echo e(_('Ongoing')); ?></p>
						<?php elseif($fromDateTime > $today && $serviceRequest->decline == 0 && $serviceRequest->closed == 0 && $serviceRequest->pending == 1): ?>
						<p class="badge badge-info"><?php echo e(_('Upcoming')); ?></p>
						<?php elseif($serviceRequest->pending==2 && $serviceRequest->decline == 0  && $serviceRequest->to < $today): ?>
						<p class="badge badge-warning"><?php echo e(_('Completed')); ?></p>
					<?php endif; ?>





						<h1 class="mbr-section-title mbr-white mbr-fonts-style display-2">
							<br>
							<strong><?php echo e($serviceRequest->pet->name ?? ''); ?></strong>
							<span style="color:#9d2e63;">
							
							</span>
						</h1>

						<!--Display pet rating with stars -->
							<?php if($rating_count > 0): ?>
							<?php for($i = 1; $i <= 5; $i++): ?>
							<?php if($i <= $rating): ?>
							<i class="fas fa-star text-warning"></i>
							<?php else: ?>
							<i class="far fa-star text-warning"></i>
							<?php endif; ?>
							<?php endfor; ?>
							<span style="color:white;"><?php echo e(round($rating, 2)); ?> (<?php echo e($rating_count. ' Reviews'); ?>) </span>
							<?php else: ?>
							<i class="far fa-star text-warning"></i> <span style="color:white;">No Rating</span>
							<?php endif; ?>


						<div class="mbr-section-text mbr-white">
							<p class="mbr-text mbr-fonts-styles mt-3">
								<?php echo e($serviceRequest->user->name); ?> <?php echo e(_('says:')); ?>

								<em><?php echo $serviceRequest->comments; ?></em>
							</p>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4" style="background:url(<?php echo e($serviceRequest->pet->photos->getUrl('preview')); ?>); background-size:cover; border-radius:1rem; background-repeat:no-repeat;">
				<!--<div class="mbr-figure mt-5" style="max-width: 180px;">
					<img class="img-circle" src="<?php echo e($serviceRequest->pet->photos->getUrl('preview')); ?>">
				</div>-->
			</div>
		</div>
	</div>
</section>

<section class="mbr-section form6 agencym4_form6 cid-ucXfcWtMY3" id="form6-3m">
	<div class="container">
		<div class="media-container-row">
			<div class="col-md-8 col-lg-8">
				<div class="text-block">
					<div class="col-lg-6 col-12 mb-4">
						<h4 class="mb-4 mbr-fonts-style display-5"><strong>Service</strong></h4>
						<p class="mbr-fonts-style display-7"><?php echo e(ucfirst($serviceRequest->service->name) ?? ''); ?></p>
					</div>
					<div class="col-lg-6 col-12 mb-4">
						<h4 class="mb-4 mbr-fonts-style display-5"><strong>Credits&nbsp;</strong></h4>
						<p class="mbr-fonts-style display-7">
							<?php echo e(\Carbon\Carbon::parse($serviceRequest->from)->diffInHours(\Carbon\Carbon::parse($serviceRequest->to)) ?? ''); ?>

							<?php echo e(_('credits')); ?>

						</p>
					</div>
					<div class="col-lg-6 col-12 mb-4">
						<h4 class="mb-4 mbr-fonts-style display-5"><strong>Pickup Date</strong></h4>
						<p class="mbr-fonts-style display-7">
							<?php echo e(\Carbon\Carbon::parse($serviceRequest->from)->format('l, F j, Y, g:i A') ?? ''); ?>

						</p>
					</div>
					<div class="col-lg-6 col-12 mb-4">
						<h4 class="mb-4 mbr-fonts-style display-5"><strong>Return Date</strong></h4>
						<p class="mbr-fonts-style display-7">
							<?php echo e(\Carbon\Carbon::parse($serviceRequest->to)->format('l, F j, Y, g:i A') ?? ''); ?>

						</p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-lg-4 block-content">
				<div>
					<div>
						<?php if($serviceRequest->closed==0 && Auth::id()!==$serviceRequest->user_id): ?>
							<form id="bookingForm" action="<?php echo e(route('frontend.bookings.store')); ?>" method="POST" enctype="multipart/form-data">
								<?php echo method_field('POST'); ?>
								<?php echo csrf_field(); ?>
								<div class="panel pb-4">
									<p class="small">
										Please be certain that you have the time blocked and that the dates work for you.
										You may lose points if you decline this service.
										As much as we love to help, we also hate to disappoint.
									</p>
								</div>
								<input type="hidden" name="credits" required="required" id="credits" value="<?php echo e(\Carbon\Carbon::parse($serviceRequest->from)->diffInHours(\Carbon\Carbon::parse($serviceRequest->to)) ?? ''); ?>">
								<input type="hidden" name="service_request_id" required="required" value="<?php echo e($serviceRequest->id); ?>">
								<input type="hidden" name="from" required="required" value="<?php echo e($serviceRequest->from); ?>">
								<input type="hidden" name="to" required="required" value="<?php echo e($serviceRequest->to); ?>">
								<input type="hidden" name="user_id" required="required" value="<?php echo e(Auth::id()); ?>">
								<input type="submit" class="btn btn-primary btn-bgr display-4" value="Book <?php echo e($serviceRequest->pet->name ?? ''); ?>" id="bookButton">
							</form>
						<?php else: ?>
							<?php if(Auth::id()==$serviceRequest->user_id && $serviceRequest->pending==0): ?>
								<a class="btn btn-success" href="<?php echo e(route('frontend.service-requests.edit', $serviceRequest->id)); ?>">
									<i class="fas fa-edit"></i> <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.serviceRequest.title_singular')); ?>

								</a>
							<?php else: ?>
								<a class="btn btn-success" href="<?php echo e(route('frontend.service-requests.index')); ?>">
									<i class="fas fa-arrow-left"></i> <?php echo e(trans('global.in_progress')); ?>

								</a>
							<?php endif; ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
	$(document).ready(function() {
		$('#bookingForm').submit(function(e) {
			e.preventDefault();
			var form = $(this);
			var submitButton = form.find('#bookButton');

			// Disable the submit button and show processing status
			submitButton.prop('disabled', true).val('Processing...');

			$.ajax({
				url: form.attr('action'),
				type: form.attr('method'),
				data: form.serialize(),
				success: function(response) {
					// Show success message
					alert('Booking successful!');

					// Redirect to the bookings page
					window.location.href = "<?php echo e(route('frontend.bookings.index')); ?>";
				},
				error: function(xhr, status, error) {
					// Show error message
					alert('An error occurred. Please try again.');

					// Enable the submit button
					submitButton.prop('disabled', false).val('Book <?php echo e($serviceRequest->pet->name ?? ''); ?>');
				}
			});
		});
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/frontend/serviceRequests/show.blade.php ENDPATH**/ ?>