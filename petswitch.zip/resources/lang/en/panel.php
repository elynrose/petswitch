<?php

return [
    'site_title' => 'Petcare',

];
